"""Reconstructed r6, NOT deployed. Trusted-host local boundary only.
No parser accepts uploaded Release objects. Host creates from its validated staging.
A real sink MUST atomically compare-and-swap expected HEAD; no GitHub sink exists.
"""
import dataclasses,hashlib,hmac,json,secrets,sqlite3,subprocess,datetime
_KEY=secrets.token_bytes(32) # process-local integrity seal; never persisted/exported

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
@dataclasses.dataclass(frozen=True,slots=True)
class Release:
 export_json:str
 base:str
 files:tuple
 allowlist:tuple
 approval_key:str
 seal:str

def body(r):return canon([r.export_json,r.base,[(p,sha(b)) for p,b in r.files],r.allowlist,r.approval_key]).encode()
def make_release(export,base,files,allowlist):
 # INTERNAL trusted builder only, not a deserializer or authorization API.
 paths=tuple(sorted(allowlist));items=tuple(sorted((str(k),bytes(v)) for k,v in files.items()))
 if not items or any(p not in paths for p,_ in items):raise ValueError('PATH_NOT_ALLOWED')
 if any(p.startswith('/') or '..' in p.split('/') or '\\' in p or '/private/' in p for p in paths):raise ValueError('UNSAFE_PATH')
 ej=canon(export);key=sha(canon([export['scheduleId'],export['scheduleHash']]).encode())
 r=Release(ej,base,items,paths,key,'')
 return dataclasses.replace(r,seal=hmac.new(_KEY,body(r),hashlib.sha256).hexdigest())
def verify(r):
 if type(r) is not Release or type(r.files) is not tuple or type(r.allowlist) is not tuple:raise ValueError('UNTRUSTED_RELEASE')
 if any(type(x) is not tuple or len(x)!=2 or type(x[0]) is not str or type(x[1]) is not bytes for x in r.files):raise ValueError('MUTABLE_FILES')
 if not hmac.compare_digest(r.seal,hmac.new(_KEY,body(r),hashlib.sha256).hexdigest()):raise ValueError('SEAL_MISMATCH')
 if len(set(p for p,_ in r.files))!=len(r.files) or any(p not in r.allowlist for p,_ in r.files):raise ValueError('PATH_NOT_ALLOWED')
 return json.loads(r.export_json)
def check_head(repo,head):
 if subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()!=head or subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip():raise ValueError('BASE_CHANGED')
class Journal:
 def __init__(self,path):
  self.path=path
  with sqlite3.connect(path) as c:c.execute('CREATE TABLE IF NOT EXISTS approvals (approval TEXT PRIMARY KEY, base TEXT NOT NULL, state TEXT NOT NULL)')
 def claim(self,key,base):
  try:
   with sqlite3.connect(self.path) as c:c.execute('INSERT INTO approvals VALUES (?,?,?)',(key,base,'CLAIMED'))
  except sqlite3.IntegrityError:raise ValueError('APPROVAL_ALREADY_CLAIMED_RECONCILE')
 def finish(self,key,state):
  with sqlite3.connect(self.path) as c:c.execute('UPDATE approvals SET state=? WHERE approval=?',(state,key))
def guarded_action(r,repo,transport,clock,journal,atomic_cas_sink):
 if not all(callable(x) for x in (transport,clock,atomic_cas_sink)) or not isinstance(journal,Journal):raise ValueError('TRUSTED_HOST_REQUIRED')
 e=verify(r);check_head(repo,r.base)
 fresh=transport(e['scheduleId'],e['scheduleHash'])
 clean=lambda x:{k:v for k,v in x.items() if k not in ('checkedAt','exportHash')}
 if clean(fresh)!=clean(e):raise ValueError('OWNER_STATE_CHANGED')
 at=datetime.datetime.fromisoformat(fresh['checkedAt'].replace('Z','+00:00'))
 if at.tzinfo is None or not 0<=(clock()-at).total_seconds()<=120:raise ValueError('OWNER_STATE_EXPIRED')
 verify(r);check_head(repo,r.base) # transport may have yielded or changed checkout
 journal.claim(r.approval_key,r.base)
 try:
  verify(r);check_head(repo,r.base) # after durable claim, immediately before sink
  # Tuple of immutable bytes, not mutable directory; sink must CAS remote expected HEAD.
  result=atomic_cas_sink(r.files,r.base)
 except BaseException:
  journal.finish(r.approval_key,'UNCERTAIN');raise
 journal.finish(r.approval_key,'COMPLETED');return result
