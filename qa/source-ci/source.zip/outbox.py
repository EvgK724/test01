"""Synthetic model of separate Google owner/outbox projects. NOT live auth.
No method below is a web endpoint. Owner assertions are trusted test-host inputs.
"""
import hashlib,json,datetime,secrets

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def iso(t):return t.isoformat().replace('+00:00','Z')
class PrivateStore:
 def __init__(self):self.record=None;self.source_revision='initial';self.public_consent=False
 def approve(self,draft,version,base_version,owner_verified,explicit_publish):
  if not owner_verified:raise ValueError('OWNER_REQUIRED')
  if not self.public_consent or explicit_publish is not True:raise ValueError('EXPLICIT_PUBLIC_PRELIMINARY_CONSENT_REQUIRED')
  # Input draft is a trusted validated canonical schedule, not arbitrary upload.
  allowed={'month','order','shift','off','duty'}
  if set(draft)!=allowed:raise ValueError('DRAFT_ALLOWLIST')
  self.record={'approvalId':secrets.token_hex(16),'draft':json.loads(json.dumps(draft)),'version':version,'baseVersion':base_version,'source':self.source_revision,'state':'APPROVED_FOR_PUBLIC_PRELIMINARY'}
 def revoke(self,owner_verified):
  if not owner_verified:raise ValueError('OWNER_REQUIRED')
  self.record['state']='REVOKED'
 def read(self,nonce,now):
  r=self.record
  if not self.public_consent or not r or r['state']!='APPROVED_FOR_PUBLIC_PRELIMINARY' or r['source']!=self.source_revision:return {'schema':1,'kind':'APPROVED_PRELIMINARY','nonce':nonce,'checkedAt':iso(now),'status':'UNAVAILABLE'}
  payload={k:r[k] for k in ('approvalId','draft','version','baseVersion')}
  return {'schema':1,'kind':'APPROVED_PRELIMINARY','nonce':nonce,'checkedAt':iso(now),'status':'READY','payload':payload,'payloadHash':digest(payload)}
