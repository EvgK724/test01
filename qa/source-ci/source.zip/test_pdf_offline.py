import unittest, tempfile, pathlib, json, sys, calendar, hashlib
from pypdf import PdfReader
import pdfplumber
sys.path.insert(0,str(pathlib.Path(__file__).parent/'source/dezhurstva/tools'))
import make_pdf
class OfflinePDF(unittest.TestCase):
 def fixture(self,root,mk='2027-01'):
  n=calendar.monthrange(int(mk[:4]),int(mk[5:]))[1]; order=list('abcdefg')
  doctors={i:{'name':'Тестовый врач '+i.upper(),'phone':'PRIVATE_PHONE_79999999999'} for i in order}
  month={'order':order,'status':'preliminary','off':[f'{mk}-02'],'marks':[],'duty':{f'{mk}-{d:02}':[order[(d-1)%7]] for d in range(1,n+1)}}
  data={'doctors':doctors,'months':{mk:month},'notes':'SECRET_NOTE','wishes':'SECRET_WISHES','sourceId':'PRIVATE_SHEET'}
  (root/'data').mkdir(exist_ok=True);(root/'data/schedule.json').write_text(json.dumps(data));return data
 def test_real_a4_content_dates_privacy_slots_and_bounds(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);data=self.fixture(root); slots=make_pdf.render(['2027-01'],root)['2027-01']
   for suffix in ('','-print'):
    p=root/'files'/f'2027-01{suffix}.pdf';r=PdfReader(p);self.assertEqual(len(r.pages),1);page=r.pages[0]
    self.assertAlmostEqual(float(page.mediabox.width),297/25.4*72,places=3);self.assertAlmostEqual(float(page.mediabox.height),210/25.4*72,places=3)
    txt=page.extract_text();self.assertIn('ПРЕДВАРИТЕЛЬНЫЙ',txt);self.assertIn('ЯНВАРЬ 2027',txt);self.assertEqual(txt.count('+'),31)
    for doctor in data['doctors'].values():self.assertIn(doctor['name'].upper(),txt)
    for banned in ['PRIVATE_PHONE','79999999999','SECRET_NOTE','SECRET_WISHES','PRIVATE_SHEET','89000000000']:self.assertNotIn(banned,txt)
    with pdfplumber.open(p) as pdf:
     chars=pdf.pages[0].chars
     self.assertTrue(all(0<=c['x0']<c['x1']<=page.mediabox.width and 0<=c['top']<c['bottom']<=page.mediabox.height for c in chars))
     words=pdf.pages[0].extract_words();headers=[w for w in words if 65<float(w['top'])<80 and w['text'].isdigit()]
     self.assertEqual([int(w['text']) for w in headers],list(range(1,32)))
    self.assertFalse(page.get('/Annots'));self.assertNotIn('/OpenAction',r.trailer['/Root'])
   self.assertEqual(set(slots),set(data['doctors']))
   self.assertTrue(all(0<x<x+w<842 and 0<y<595 for x,y,w in slots.values()))
 def test_one_day_leave_has_readable_marker_and_legend(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);data=self.fixture(root)
   data['months']['2027-01']['marks']=[{'who':'b','from':'2027-01-01','to':'2027-01-01','label':'Отпуск'}]
   (root/'data/schedule.json').write_text(json.dumps(data));make_pdf.render(['2027-01'],root)
   for suffix in ('','-print'):
    p=root/'files'/f'2027-01{suffix}.pdf';r=PdfReader(p);self.assertEqual(len(r.pages),1);txt=r.pages[0].extract_text()
    self.assertIn('М1 - ОТПУСК',txt);self.assertEqual(txt.count('М1'),2);self.assertEqual(txt.count('+'),31)
    with pdfplumber.open(p) as pdf:self.assertTrue(all(c['x0']>=0 and c['x1']<=842 and c['top']>=0 and c['bottom']<=595.3 for c in pdf.pages[0].chars))
 def test_leap_month_and_determinism(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);self.fixture(root,'2028-02');make_pdf.render(['2028-02'],root);p=root/'files/2028-02.pdf';a=p.read_bytes();make_pdf.render(['2028-02'],root);self.assertEqual(a,p.read_bytes());self.assertEqual(PdfReader(p).pages[0].extract_text().count('+'),29)
 def test_invalid_date_and_mark_conflict_fail(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);data=self.fixture(root);data['months']['2027-01']['duty']['2027-02-01']=['a'];(root/'data/schedule.json').write_text(json.dumps(data))
   with self.assertRaisesRegex(ValueError,'PDF_DUTY'):make_pdf.render(['2027-01'],root)
   data=self.fixture(root);data['months']['2027-01']['marks']=[{'who':'a','from':'2027-01-01','to':'2027-01-02','label':'Отпуск'}];(root/'data/schedule.json').write_text(json.dumps(data))
   with self.assertRaisesRegex(ValueError,'PDF_MARK_CONFLICT'):make_pdf.render(['2027-01'],root)
if __name__=='__main__':unittest.main()
