import unittest,tempfile,pathlib,subprocess,json,datetime,shutil,os
from outbox import PrivateStore,digest
from delivery import deliver,git,RECEIPTS,SCHEDULE,checked
from real_renderer import render
from release_boundary import sha
class T(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name);self.remote=self.root/'remote.git';subprocess.run(['git','init','--bare','-q',str(self.remote)],check=True);self.repo=self.root/'work';subprocess.run(['git','clone','-q',str(self.remote),str(self.repo)],check=True);git(self.repo,'checkout','-qb','main')
  shutil.copytree(pathlib.Path(__file__).parent/'source/dezhurstva',self.repo/'dezhurstva',dirs_exist_ok=True)
  pdf=self.repo/'dezhurstva/tools/make_pdf.py'
  if os.environ.get('DUTY_TEST_CHROMIUM'):pdf.write_text(pdf.read_text().replace('p.chromium.launch()', 'p.chromium.launch(executable_path='+repr(os.environ['DUTY_TEST_CHROMIUM'])+')'))
  path=self.repo/SCHEDULE;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps({'tz':'Asia/Yekaterinburg','updated':'2026-12-10T12:00:00Z','doctors':{'a':{'name':'Synthetic A'},'b':{'name':'Synthetic B'}},'months':{}}));git(self.repo,'add','.');git(self.repo,'-c','user.name=T','-c','user.email=t@example.invalid','commit','-qm','base');git(self.repo,'push','-u','origin','main')
  self.pins={x:sha((self.repo/x).read_bytes()) for x in git(self.repo,'ls-files','-z','dezhurstva').strip('\0').split('\0')}
  self.now=datetime.datetime.now(datetime.timezone.utc);self.store=PrivateStore();self.store.public_consent=True
  self.d={'month':'2027-01','order':['a','b'],'off':[],'shift':{'work':['08:00','20:00'],'off':['08:00','08:00']},'duty':{f'2027-01-{i:02}':['a'if i%2 else'b']for i in range(1,32)}};self.store.approve(self.d,1,0,True,True);self.pages=[]
 def tearDown(self):self.tmp.cleanup()
 def transport(self,n):return self.store.read(n,self.now)
 def render(self,d,v,r,h):return render(d,v,r,h,self.pins)
 def runit(self,**kw):return deliver(self.repo,self.transport,lambda:self.now,kw.pop('pages_verify',lambda c:self.pages.append(c)),renderer=self.render,expected_approval_id=self.store.record['approvalId'],**kw)
 def add_historical_final(self):
  path=self.repo/SCHEDULE;data=json.loads(path.read_text())
  self.historical={'title':'Декабрь 2026','status':'final','version':4,'final_at':'2026-11-15T10:00:00Z','order':['a','b'],'off':[],'marks':[],'shift':self.d['shift'],'duty':{f'2026-12-{d:02}':['a' if d%2 else 'b'] for d in range(1,32)}}
  data['months']['2026-12']=self.historical;path.write_text(json.dumps(data))
  tool=self.repo/'dezhurstva/tools'
  # Produce real, complete historical artifacts with old cache format 5.
  subprocess.run(['python','-c',"import sys;sys.path.insert(0,sys.argv[1]);import build;build.PDF_FORMAT=5;build.main()",str(tool)],cwd=self.repo,check=True,capture_output=True)
  git(self.repo,'add','.');git(self.repo,'-c','user.name=T','-c','user.email=t@example.invalid','commit','-qm','historical final release');git(self.repo,'push','origin','HEAD:main')
  self.pins={x:sha((self.repo/x).read_bytes()) for x in git(self.repo,'ls-files','-z','dezhurstva').strip('\0').split('\0')}
 def test_historical_final_artifacts_preserved(self):
  self.add_historical_final()
  artifacts={suffix:(self.repo/f'dezhurstva/files/2026-12{suffix}').read_bytes() for suffix in ('.pdf','-print.pdf','.xlsx')}
  meta={name:json.loads((self.repo/'dezhurstva/files'/name).read_text())['2026-12'] for name in ('pdf.json','hashes.json')}
  result=self.runit()
  self.assertEqual(json.loads((self.repo/SCHEDULE).read_text())['months']['2026-12'],self.historical)
  for suffix,value in artifacts.items():self.assertEqual((self.repo/f'dezhurstva/files/2026-12{suffix}').read_bytes(),value)
  for name,value in meta.items():self.assertEqual(json.loads((self.repo/'dezhurstva/files'/name).read_text())['2026-12'],value)
  changed=git(self.repo,'diff-tree','--no-commit-id','--name-only','-r',result['commit'])
  self.assertNotIn('files/2026-12',changed)
 def test_missing_historical_artifact_fails_without_repair(self):
  self.add_historical_final();(self.repo/'dezhurstva/files/2026-12.pdf').unlink();git(self.repo,'add','-u');git(self.repo,'-c','user.name=T','-c','user.email=t@example.invalid','commit','-qm','synthetic missing historical artifact');git(self.repo,'push','origin','HEAD:main')
  self.pins={x:sha((self.repo/x).read_bytes()) for x in git(self.repo,'ls-files','-z','dezhurstva').strip('\0').split('\0')}
  before=git(self.repo,'rev-parse','origin/main')
  with self.assertRaises(subprocess.CalledProcessError):self.runit()
  self.assertEqual(git(self.repo,'rev-parse','origin/main'),before)
 def test_owner_and_public_consent(self):
  s=PrivateStore()
  with self.assertRaisesRegex(ValueError,'OWNER'):s.approve(self.d,1,0,False,True)
  with self.assertRaisesRegex(ValueError,'CONSENT'):s.approve(self.d,1,0,True,True)
  self.assertEqual(s.read('n',self.now)['status'],'UNAVAILABLE')
 def test_public_schema_no_private(self):
  r=self.transport('n');self.assertEqual(checked(r,'n',self.now)['draft'],self.d)
  for key in ['wishes','notes','source','owner','vacation']:
   self.assertNotIn('"'+key+'"',json.dumps(r))
  r['raw']='bad'
  with self.assertRaisesRegex(ValueError,'SCHEMA'):checked(r,'n',self.now)
 def test_commit_receipt_same_commit_replay_pages_repair(self):
  result=self.runit();commit=result['commit'];changed=set(git(self.repo,'diff-tree','--no-commit-id','--name-only','-r',commit).splitlines());self.assertTrue({SCHEDULE,RECEIPTS,'dezhurstva/index.html','dezhurstva/files/2027-01.pdf'}<=changed)
  from pypdf import PdfReader
  for suffix in ('','-print'):
   pdf=self.repo/f'dezhurstva/files/2027-01{suffix}.pdf';reader=PdfReader(pdf);self.assertEqual(len(reader.pages),1);self.assertIn('SYNTHETIC',reader.pages[0].extract_text().upper())
   if os.environ.get('DUTY_TEST_REPORT_DIR'):
    out=pathlib.Path(os.environ['DUTY_TEST_REPORT_DIR']);out.mkdir(parents=True,exist_ok=True);shutil.copyfile(pdf,out/pdf.name)
  again=self.runit();self.assertEqual(again['commit'],commit);self.assertEqual(again['status'],'ALREADY_COMMITTED')
 def test_revoke_or_source_stale_before_publish(self):
  self.store.source_revision='new'
  with self.assertRaisesRegex(ValueError,'REVOKED'):self.runit()
  self.store.source_revision='initial';self.store.revoke(True)
  with self.assertRaisesRegex(ValueError,'REVOKED'):self.runit()
 def test_revoke_between_reads(self):
  n=0
  def transport(nonce):
   nonlocal n;n+=1
   if n==2:self.store.revoke(True)
   return self.transport(nonce)
  before=git(self.repo,'rev-parse','origin/main')
  with self.assertRaisesRegex(ValueError,'REVOKED'):deliver(self.repo,transport,lambda:self.now,lambda _:None,renderer=self.render)
  self.assertEqual(git(self.repo,'rev-parse','origin/main'),before)
 def test_late_revoke_not_atomic_report_review(self):
  result=self.runit(before_push=lambda:self.store.revoke(True));self.assertTrue(result['organizerReviewRequired']);self.assertEqual(json.loads((self.repo/SCHEDULE).read_text())['months']['2027-01']['status'],'preliminary')
 def test_push_timeout_after_success_reconciles(self):
  def push(repo):git(repo,'push','origin','HEAD:main');raise TimeoutError('synthetic lost response')
  r=self.runit(push=push);self.assertEqual(git(self.repo,'rev-parse','origin/main'),r['commit']);self.assertEqual(len(json.loads((self.repo/RECEIPTS).read_text())),1)
 def test_concurrent_confirmation_commit_rejects(self):
  other=self.root/'other';subprocess.run(['git','clone','-q','-b','main',str(self.remote),str(other)],check=True)
  def race():
   (other/'synthetic-confirmation').write_text('concurrent');git(other,'add','.');git(other,'-c','user.name=T','-c','user.email=t@example.invalid','commit','-qm','concurrent');git(other,'push','origin','HEAD:main')
  with self.assertRaisesRegex(ValueError,'PUSH_NOT_CONFIRMED'):self.runit(before_push=race)
  self.assertEqual(git(self.repo,'rev-parse','origin/main'),git(other,'rev-parse','HEAD'))
 def test_pages_failure_then_retry_no_new_version(self):
  def fail(_):raise RuntimeError('synthetic Pages unavailable')
  result=self.runit(pages_verify=fail);self.assertEqual(result['pages'],'FAILED_RETRY_SAME_COMMIT')
  h=git(self.repo,'rev-parse','HEAD');r=self.runit();self.assertEqual(r['commit'],h);self.assertEqual(json.loads((self.repo/SCHEDULE).read_text())['months']['2027-01']['version'],1)
 def test_combined_late_revoke_pages_failure_recovers_durably(self):
  def fail(_):raise RuntimeError('synthetic Pages down')
  result=self.runit(before_push=lambda:self.store.revoke(True),pages_verify=fail)
  self.assertTrue(result['organizerReviewRequired']);self.assertEqual(result['pages'],'FAILED_RETRY_SAME_COMMIT');commit=result['commit']
  # Retry revoked outbox: reconcile receipt before interpreting UNAVAILABLE. No new commit.
  result=self.runit();self.assertEqual(result['commit'],commit);self.assertEqual(result['publicationCommit'],commit);self.assertTrue(result['organizerReviewRequired']);self.assertEqual(result['pages'],'VERIFIED')
  self.assertEqual(len(json.loads((self.repo/RECEIPTS).read_text())),1)
 def test_source_outage_after_commit_pages_failure_survives(self):
  def fail(_):raise RuntimeError('Pages')
  first=self.runit(pages_verify=fail);self.store.source_revision='changed'
  second=self.runit(pages_verify=fail);self.assertTrue(second['organizerReviewRequired']);self.assertEqual(second['commit'],first['commit']);self.assertEqual(second['pages'],'FAILED_RETRY_SAME_COMMIT')
  def unavailable(_):raise TimeoutError('synthetic transport')
  third=deliver(self.repo,unavailable,lambda:self.now,lambda _:None,renderer=self.render,expected_approval_id=self.store.record['approvalId']);self.assertTrue(third['organizerReviewRequired']);self.assertEqual(third['commit'],first['commit'])
if __name__=='__main__':unittest.main()
