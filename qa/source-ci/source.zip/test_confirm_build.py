import unittest,json,subprocess,pathlib,importlib.util
from test_delivery import T
from delivery import git,SCHEDULE
class ScopedConfirmation(T):
 def test_finalization_build_preserves_old_final_month(self):
  self.add_historical_final();self.runit();base=git(self.repo,'rev-parse','HEAD')
  oldbytes={s:(self.repo/f'dezhurstva/files/2026-12{s}').read_bytes() for s in ('.pdf','-print.pdf','.xlsx')}
  metadata={f:json.loads((self.repo/'dezhurstva/files'/f).read_text())['2026-12'] for f in ('pdf.json','hashes.json')}
  spec=importlib.util.spec_from_file_location('rev_current',self.repo/'dezhurstva/tools/approval_revision.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  data=json.loads((self.repo/SCHEDULE).read_text());m=data['months']['2027-01'];m['status']='final';m['confirm']['confirmed']=m['confirm']['need'];m['confirm']['disagreed']=0;m['finalization']={'digest':mod.revision(m,data)}
  (self.repo/SCHEDULE).write_text(json.dumps(data))
  for script in ('build_confirmations.py','publication_guard.py'):
   subprocess.run(['python','-B',str(self.repo/'dezhurstva/tools'/script),'--base',base],cwd=self.repo,check=True,capture_output=True)
  for suffix,raw in oldbytes.items():self.assertEqual((self.repo/f'dezhurstva/files/2026-12{suffix}').read_bytes(),raw)
  for f,old in metadata.items():self.assertEqual(json.loads((self.repo/'dezhurstva/files'/f).read_text())['2026-12'],old)
  from pypdf import PdfReader
  text=PdfReader(self.repo/'dezhurstva/files/2027-01.pdf').pages[0].extract_text();self.assertNotIn('ПРЕДВАРИТЕЛЬНЫЙ',text);self.assertEqual(text.count('+'),31)
for name in T.__dict__:
 if name.startswith('test_'):setattr(ScopedConfirmation,name,None)
if __name__=='__main__':unittest.main()
