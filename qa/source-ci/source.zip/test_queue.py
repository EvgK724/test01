import unittest,datetime,json,tempfile,pathlib
from unittest.mock import patch
import queue_consumer as q
from outbox import digest
class T(unittest.TestCase):
 def setUp(self):
  self.now=datetime.datetime.now(datetime.timezone.utc);self.tmp=tempfile.TemporaryDirectory();self.repo=pathlib.Path(self.tmp.name)
  p=self.repo/q.SCHEDULE;p.parent.mkdir(parents=True);p.write_text('{"months":{}}')
 def tearDown(self):self.tmp.cleanup()
 def cat(self,n,ids):return dict(schema=1,kind='APPROVAL_CATALOG',nonce=n,checkedAt=self.now.isoformat(),status='READY',approvalIds=ids)
 def payload(self,aid):return dict(approvalId=aid,baseVersion=0,version=1,draft=dict(month='2027-01',order=['a','b'],off=[],shift={'work':['08:00','20:00'],'off':['08:00','08:00']},duty={f'2027-01-{i:02}':['a'if i%2 else'b']for i in range(1,32)}))
 def read(self,aid,n):
  p=self.payload(aid);return dict(schema=1,kind='APPROVED_PRELIMINARY',nonce=n,checkedAt=self.now.isoformat(),status='READY',payload=p,payloadHash=digest(p))
 def runq(self,ids,selected=None):
  def git(repo,*args):return ''if args[0]=='status'else 'abc'
  with patch.object(q,'git',git):return q.consume(self.repo,lambda n:self.cat(n,ids),selected or self.read,lambda:self.now,lambda c:None,lambda *a:None)
 def test_catalog(self):self.assertEqual(q.catalog_checked(self.cat('n',['a'*32]),'n',self.now),['a'*32])
 def test_duplicate_and_limit(self):
  for ids in [['a'*32]*2,[f'{x:032x}'for x in range(501)]]:
   with self.assertRaisesRegex(ValueError,'IDS'):q.catalog_checked(self.cat('n',ids),'n',self.now)
 def test_stale(self):
  with self.assertRaisesRegex(ValueError,'STALE'):q.catalog_checked(self.cat('n',[]),'n',self.now+datetime.timedelta(seconds=121))
 def test_empty(self):self.assertTrue(self.runq([])['empty'])
 def test_conflict_no_delivery(self):
  with patch.object(q,'deliver')as d:
   with self.assertRaisesRegex(ValueError,'CONFLICT'):self.runq(['a'*32,'b'*32])
   d.assert_not_called()
 def test_selector_no_delivery(self):
  with patch.object(q,'deliver')as d:
   with self.assertRaisesRegex(ValueError,'SELECTOR'):self.runq(['a'*32],lambda a,n:self.read('b'*32,n))
   d.assert_not_called()
 def test_selected_delivery(self):
  with patch.object(q,'deliver',return_value={'status':'SYNTHETIC'})as d:
   self.runq(['a'*32]);self.assertEqual(d.call_args.kwargs['expected_approval_id'],'a'*32)
 def receipt(self,aid,month='2027-01'):
  return dict(approvalId=aid,month=month,version=1,payloadHash=digest(self.payload(aid)))
 def test_old_receipt_superseded_only_latest_checked(self):
  (self.repo/q.RECEIPTS).write_text(json.dumps([self.receipt('a'*32),self.receipt('b'*32)]))
  calls=[]
  def selected(a,n):calls.append(a);return self.read(a,n)
  with patch.object(q,'finish_committed',return_value={'pages':'VERIFIED','organizerReviewRequired':False}):self.runq([],selected)
  self.assertEqual(calls,['b'*32])
 def test_active_revocation_stops_pending_other_month(self):
  (self.repo/q.RECEIPTS).write_text(json.dumps([self.receipt('a'*32,'2026-12')]))
  with patch.object(q,'finish_committed',return_value={'pages':'VERIFIED','organizerReviewRequired':True}),patch.object(q,'deliver')as d:
   self.runq(['b'*32]);d.assert_not_called()
 def test_exact_base_new_approval_can_replace_stale_snapshot(self):
  (self.repo/q.RECEIPTS).write_text(json.dumps([self.receipt('a'*32)]))
  # Synthetic current version 0 deliberately matches the fresh candidate base.
  with patch.object(q,'finish_committed')as f,patch.object(q,'deliver',return_value={'pages':'VERIFIED','organizerReviewRequired':False})as d:
   self.runq(['b'*32]);f.assert_not_called();d.assert_called_once()
if __name__=='__main__':unittest.main()
